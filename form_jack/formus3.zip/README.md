# agoraTest
Aplicación dedicada a la gestión de información de colegios
