<?php
namespace Config;

	use \merge\FPDI 	as FPDI;
	
	class MergePDF extends FPDI{

	}
	
?>