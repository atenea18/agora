<?php
namespace App\Config;
 
abstract class Response{
    
    abstract public function execute();
}

