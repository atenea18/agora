<?php 
namespace App\Controller;

use App\Config\View as View;
use App\Model\InstitutionModel as Institution;
/**
* 
*/
class InstitutionController
{
	
	function __construct()
	{
		
	}

	function indexAction()
	{

	}

	public function showFormgradeBookAction($db)
	{	
		
		$institution = new Institution($db);
		print_r($institution->getSedes()['data'];);
		
	}

}

?>