<?php 
	
	namespace Controllers;
	
	use Config\View 	as View;
	use Model\AsignaturaModel	as Asignatura;

	class HomeController{

		public function indexAction(){
			
		}
	}
?>