<?php namespace Config;
 
abstract class Response{
    
    abstract public function execute();
}

